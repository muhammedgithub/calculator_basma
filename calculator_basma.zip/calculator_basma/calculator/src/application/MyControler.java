package application;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.*;
public class MyControler {
	
	double number1;
	double number2;
	double result;
	char opretion;
	@FXML
     private	TextField txtResult;
	
	
	@FXML
	private RadioButton sum;
	@FXML
	private RadioButton sub;
	@FXML
	private RadioButton mul;
	@FXML
	private RadioButton div;

	
	MyMethod method=new MyMethod();
	
	
	private void setOpretion (char opr) {
		number1=Double.parseDouble(txtResult.getText());
		txtResult.setText("");
		opretion=opr;
	}
 

	
	
	public void btn1 () {
		method.setTexNo("1",txtResult);
	}
	
	
	public void btn2 () {
		method.setTexNo("2",txtResult);
	}
	
	public void btn3 () {
		method.setTexNo("3",txtResult);
	}
	
	public void btn4 () {
		method.setTexNo("4",txtResult);
	}
	public void btn5 () {
		method.setTexNo("5",txtResult);
	}
	public void btn6 () {
		method.setTexNo("6",txtResult);
	}
	public void btn7 () {
		method.setTexNo("7",txtResult);
	}
	public void btn8 () {
		method.setTexNo("8",txtResult);
	}
	public void btn9 () {
		method.setTexNo("9",txtResult);
	}
	public void btn0 () {
		method.setTexNo("0",txtResult);
	}
	
	public void btnp () {
		method.setTexNo(".",txtResult);
	}
	
	
	
	public void opSum () {
		setOpretion('+');
	}
	public void opSub () {
		setOpretion('-');
	}
	public void opMul () {
		setOpretion('*');
	}
	public void opDiv () {
		setOpretion('/');
	}
	
	
	public void signal () {
		double no=Double.parseDouble(txtResult.getText());
		no=no*-1;
		txtResult.setText(String.valueOf(no));
	}
	
	public void btnAC () {
		
		txtResult.setText("");
	}
	
	public void btnOFF () {System.exit(0);}
	
	
	
	public void equle () {
		number2=Double.parseDouble(txtResult.getText());
		switch (opretion) {
		case'+':result=number1+number2; break;
		case'-':result=number1-number2; break;
		case'*':result=number1*number2; break;
		case'/':result=number1/number2; break;
		}
		txtResult.setText(String.valueOf(result));
	}
}

