package application;

import javafx.scene.control.TextField;

public class MyMethod {
	
	public void setTexNo(String s,TextField t) {
		String ss=t.getText()+s;
		t.setText(ss);
	}
	
	

}
